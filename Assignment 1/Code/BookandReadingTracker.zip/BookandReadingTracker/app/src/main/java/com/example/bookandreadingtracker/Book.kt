package com.example.bookandreadingtracker

data class Book(
    val title: String,
    val progress: Int
)

// Sample data
val sampleBooks = listOf(
    Book("The Hobbit", 50),
    Book("1984", 75),
    Book("Atomic Habits", 30)
)