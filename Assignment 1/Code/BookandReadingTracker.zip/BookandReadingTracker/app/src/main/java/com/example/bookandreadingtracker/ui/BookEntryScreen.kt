package com.example.bookandreadingtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookEntryScreen(navController: NavController) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Add a Book") }) },
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            Text("Enter book details here", style = MaterialTheme.typography.bodyLarge)
        }
    }
}


