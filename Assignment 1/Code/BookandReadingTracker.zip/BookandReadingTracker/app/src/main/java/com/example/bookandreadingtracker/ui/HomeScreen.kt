package com.example.bookandreadingtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.bookandreadingtracker.Book
import com.example.bookandreadingtracker.sampleBooks

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Reading Stats") },
                colors = TopAppBarDefaults.topAppBarColors()
            )
        },
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            Text("Books in Progress", style = MaterialTheme.typography.headlineSmall)

            LazyColumn {
                items(sampleBooks) { book ->
                    BookCard(book)
                }
            }
        }
    }
}

@Composable
fun BookCard(book: Book) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(8.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(book.title, style = MaterialTheme.typography.bodyLarge)
            Text("Progress: ${book.progress}%", style = MaterialTheme.typography.bodyMedium)
            LinearProgressIndicator(
                progress = book.progress / 100f,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
    }
}
