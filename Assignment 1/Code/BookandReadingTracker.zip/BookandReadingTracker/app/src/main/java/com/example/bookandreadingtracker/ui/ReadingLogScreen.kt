package com.example.bookandreadingtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadingLogScreen(navController: NavController) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Reading Log") }) },
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            Text("Your past readings will be displayed here.", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
