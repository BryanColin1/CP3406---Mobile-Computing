package com.example.bookandreadingtracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecommendationsScreen(navController: NavController) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Book Recommendations") }) },
        bottomBar = { BottomNavigationBar(navController) }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues).padding(16.dp)) {
            Text("AI-based recommendations will appear here.", style = MaterialTheme.typography.bodyLarge)
        }
    }
}


