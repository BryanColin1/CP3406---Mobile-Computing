package com.example.bookandreadingtracker.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun BookTrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(), // Default Material 3 color scheme
        typography = Typography(),
        content = content
    )
}

// Preview
@Preview
@Composable
fun PreviewTheme() {
    BookTrackerTheme {
        Text("Hello, Material 3!")
    }
}
